package com.Exception;

public class CartCreateException extends Exception{
	
	public CartCreateException(String message) {
		 super(message);
}

}
