package com.Exception;

public class CartUpdateException extends Exception{
	
	public CartUpdateException(String message) {
		 super(message);
}

}
