package com.Exception;

public class CategoryCreateException extends RuntimeException{
	
	public CategoryCreateException(String message) {
		 super(message);
 }

}
