package com.Exception;

public class ReviewNotFoundException extends Exception{
	
	public ReviewNotFoundException(String message) {
		 super(message);
 }


}
