package com.entity;

public enum Role {
	BUYER, SELLER ;

}
